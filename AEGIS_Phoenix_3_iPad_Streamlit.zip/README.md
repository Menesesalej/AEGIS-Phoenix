# AEGIS Phoenix 3.0 — Apple AAPL

Calculadora educativa Streamlit para navegador (incluye Safari en iPad). No es una app nativa y el ZIP no se abre como página web.

## Publicar en Streamlit Community Cloud
1. Crea una cuenta en GitHub y un repositorio nuevo, por ejemplo `aegis-phoenix`.
2. Sube **app.py** y **requirements.txt** a la raíz del repositorio (no subas el ZIP sin descomprimir).
3. En https://share.streamlit.io/ inicia sesión con GitHub, selecciona **Create app**, el repositorio y la rama principal.
4. En Main file path escribe `app.py` y selecciona Deploy.
5. Abre la URL que genere Streamlit desde Safari en tu iPad. Puedes usar Compartir > Agregar a pantalla de inicio.

## Cómo editar supuestos en clase
- Barra lateral: precio de Apple, días, tasa, dividendos y volatilidad.
- Tabla: agrega, quita o modifica opciones, strikes, cantidades y Bid/Ask.
- Método de prima: teórico o Bid/Ask capturados. No se completan automáticamente cotizaciones faltantes.
- Campo **Supuesto del profesor**: precio de AAPL al vencimiento y resultado inmediato.
- Botón **Restablecer**: recupera la estructura original.

## Importante
Los valores iniciales son históricos/ilustrativos, no un feed en vivo. La curva IRS es una curva plana didáctica. Los modelos teóricos no equivalen a primas ejecutables. El payoff al vencimiento sí se traza por segmentos rectos.

## Ejecución local opcional
`pip install -r requirements.txt`
`streamlit run app.py`
